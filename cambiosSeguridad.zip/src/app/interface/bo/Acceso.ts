export class Acceso {

  opcion: string;
  alta:   string;
  baja:   string;
  cambio: string;
  consulta: string;

  constructor( opcion: string,
               alta:   string,
               baja:   string,
               cambio: string,
               consulta: string
  ) {
    this.opcion = opcion;
    this.alta = alta;
    this.baja = baja;
    this.cambio = cambio;
    this.consulta = consulta;
  }

}
